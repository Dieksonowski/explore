package com.sasumikonranta.gostats;

/**
 * Created by Saz on 15.2.2015.
 */

import android.app.Application;

public class Global extends Application{


    /* TÄNNE GLOBAL MUUTTUJAT JOITA VOI KÄYTTÄÄ VAPAASTI ERI ACTIVITYISSA
       Globaleita voi käyttää muualla määrittelemällä ne näin:

    Global g = (Global)getApplication();
    int numero = g.getNumero();  //tämä getter sijaitsee Global luokassa


    */

}

