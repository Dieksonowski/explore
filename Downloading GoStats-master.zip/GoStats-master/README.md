# GoStats
Android project for CS:GO Stats app

GOStats on tarkoitettu seuraamaan pelaajan tietoja Counter-Strike: Global Offensive pelistä. Android ohjelma ilmaisee pelaajan
tuloksia selkeästi ja hakee ne valven sivuilta. Tarkoituksena olisi pelaajan pystyä seurata omaa kehitystään ajan mukaan.

-Sasu M.
